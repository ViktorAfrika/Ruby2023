module QuizName
  self.included(class_instance)
end 
